/**
 * \file
 *         A very simple Contiki application showing how Contiki programs look
 * \author
 *         mds
 */

#include "contiki.h"
#include <stdio.h> /* For printf() */
#include <stdbool.h>
#include "dev/leds.h"
#include "ieee-addr.h"
#include "dev/serial-line.h"
#include "dev/cc26xx-uart.h"
#include "buzzer.h"
#include <string.h>
#include "sys/etimer.h"
/*---------------------------------------------------------------------------*/
//PROCESS(prac1, "prac1");
PROCESS(input_process, "input process");
PROCESS(led_process, "led_process");
PROCESS(buzzer_process, "buzzer process");
AUTOSTART_PROCESSES(&input_process, &led_process, &buzzer_process);
/*---------------------------------------------------------------------------*/

//Global Vars
bool red = false, green = false, buzz_state = false;
int buzz_freq = 10000;



PROCESS_THREAD(led_process, ev, data){

	static struct etimer et;

	PROCESS_BEGIN();
	
	etimer_set(&et, CLOCK_SECOND);
	while(1){
		if(red){
			leds_toggle(LEDS_RED);
		} else {
			leds_off(LEDS_RED);
		}
		if(green){
			leds_toggle(LEDS_GREEN);
		} else {
			leds_off(LEDS_GREEN);
		}

		PROCESS_WAIT_EVENT_UNTIL(etimer_expired(&et));
		etimer_reset(&et);
	}
	
	PROCESS_END();
}


PROCESS_THREAD(buzzer_process, ev, data){

	static struct etimer et;

	PROCESS_BEGIN();
	
	while(1){

		PROCESS_WAIT_EVENT();
	
		if(strcmp("b",data)==0){
			buzz_state = !buzz_state;
			if(buzz_state){
				buzzer_start(buzz_freq);
			} else {
				buzzer_stop();
			}
		} else if (strcmp("i", data)==0){
			buzz_freq = buzz_freq + 5000;
			if(buzz_state){
				buzzer_start(buzz_freq);
			}
			etimer_set(&et, 5*CLOCK_SECOND);
			printf("waiting\n");
			PROCESS_WAIT_EVENT_UNTIL(etimer_expired(&et));
			buzz_freq = buzz_freq - 5000;
			if(buzz_state){
				buzzer_start(buzz_freq);
			}
		} else if (strcmp("d", data)==0){
			buzz_freq = buzz_freq - 5000;
			if(buzz_state){
				buzzer_start(buzz_freq);
			}
			etimer_set(&et, 5*CLOCK_SECOND);
			printf("waiting\n");
			PROCESS_WAIT_EVENT_UNTIL(etimer_expired(&et));
			buzz_freq = buzz_freq + 5000;
			if(buzz_state){
				buzzer_start(buzz_freq);
			}
		}

	}
	PROCESS_END();
}


PROCESS_THREAD(input_process, ev, data){

	PROCESS_BEGIN();

	char msg;
	cc26xx_uart_set_input(serial_line_input_byte);
	//char input;
	while(1){

		PROCESS_YIELD();
		if(ev == serial_line_event_message) {
			if(strcmp(data,"r")==0){
				red = !red;
				printf("turn on Red toggle");

			} else if(strcmp(data,"g")==0){
				green = !green;
				printf("green toggle\n");

			} else 	if(strcmp(data,"a")==0){
				red = !red;
				green = !green;
				printf("all toggle\n");

			} else if(strcmp(data,"b")==0){
				msg = 'b';
				process_post(&buzzer_process, PROCESS_EVENT_CONTINUE, &msg);
				printf("buzzer toggle\n");
		
			} else if(strcmp(data,"i")==0){
				msg = 'i';				
				process_post(&buzzer_process, PROCESS_EVENT_CONTINUE, &msg);
				printf("Freq Inc\n");
			
			} else if(strcmp(data,"d")==0){
				msg = 'd';
				process_post(&buzzer_process, PROCESS_EVENT_CONTINUE, &msg);
				printf("Freq Dec\n");

			} else if(strcmp(data,"n")==0){
				uint8_t * addrP, addr[8];
				addrP = &addr;
				ieee_addr_cpy_to(addrP, 8);
				printf("IEEE ADDR: ");	
				for(int i =0; i< 8; i++){
					printf("%x", addr[i]);	
				}
				printf("\n");
			} else {
				printf(data);
				printf("\n");
			}
		}
	}
	PROCESS_END();

}

/*---------------------------------------------------------------------------*/
